/* =========================================
   SMART COMMUNITY REPORTING
   MAIN JAVASCRIPT
========================================= */


/* =========================================
   LOGIN
========================================= */

function loginUser(event) {

    event.preventDefault();

    const email = document.getElementById("loginEmail").value;
    const password = document.getElementById("loginPassword").value;

    if (email && password) {

        localStorage.setItem("smartCommunityUser", email);

        alert("Login successful! Welcome to Smart Community Reporting.");

        window.location.href = "dashboard.html";

    }

}


/* =========================================
   REGISTER
========================================= */

function registerUser(event) {

    event.preventDefault();

    const firstName =
        document.getElementById("firstName").value;

    const lastName =
        document.getElementById("lastName").value;

    const email =
        document.getElementById("registerEmail").value;

    if (firstName && lastName && email) {

        localStorage.setItem(
            "smartCommunityUser",
            email
        );

        alert(
            "Account created successfully! You can now access your dashboard."
        );

        window.location.href = "dashboard.html";

    }

}


/* =========================================
   LOGOUT
========================================= */

function logoutUser() {

    localStorage.removeItem("smartCommunityUser");

}


/* =========================================
   SIDEBAR
========================================= */

function toggleSidebar() {

    const sidebar =
        document.querySelector(".sidebar");

    if (sidebar) {

        sidebar.classList.toggle("show");

    }

}


/* =========================================
   REPORT SUBMISSION
========================================= */

function submitReport(event) {

    event.preventDefault();

    const title =
        document.getElementById("issueTitle").value;

    const category =
        document.getElementById("issueCategory").value;

    const location =
        document.getElementById("issueLocation").value;

    const priority =
        document.getElementById("issuePriority").value;

    const description =
        document.getElementById("issueDescription").value;


    if (
        title &&
        category &&
        location &&
        priority &&
        description
    ) {

        const report = {

            id: "SCR-" + Date.now(),

            title: title,

            category: category,

            location: location,

            priority: priority,

            description: description,

            status: "Pending",

            date: new Date().toLocaleDateString()

        };


        let reports =
            JSON.parse(
                localStorage.getItem("communityReports")
            ) || [];


        reports.push(report);


        localStorage.setItem(
            "communityReports",
            JSON.stringify(reports)
        );


        alert(
            "Report submitted successfully!\n\nReport ID: "
            + report.id
        );


        window.location.href = "my-reports.html";

    }

}


/* =========================================
   GENERAL MESSAGE
========================================= */

function showMessage(message) {

    alert(message);

}


/* =========================================
   LOAD SAVED REPORTS
========================================= */

function loadReports() {

    const reports =
        JSON.parse(
            localStorage.getItem("communityReports")
        ) || [];

    console.log("Community Reports:", reports);

}


/* =========================================
   PAGE READY
========================================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        loadReports();

    }
);